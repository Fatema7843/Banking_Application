import java.util.ArrayList;
public class Bank {
		private ArrayList<Account> List;
		 public Bank()
		 {
			 List = new ArrayList<Account>();
		 }
		 public void addAccount(Account account)
		 {
			 List.add(account);
		 }
		 public void removeAccount(Account account)
		 {
			 List.remove(account);
		 }
		public void Transfer(Account sender,Account receiver,double amount)
		{
			if(sender.withdraw(amount,true))
			{
				System.out.println();
				if(receiver.deposite(amount,true))
				{
					//System.out.println();
					System.out.println("Transfer successfully done");
					sender.addTransaction(sender, receiver, amount, "Transfer");
					receiver.addTransaction(sender, receiver, amount, "Transfer");
					//System.out.println();
				}
				else
				{
					System.out.println();
					sender.deposite(amount,true);
					System.out.println("Something went wrong");
					//System.out.println();
				}
			}
			else
			{
				System.out.println();
				System.out.println("Something went wrong");
				//System.out.println();
			}
			
			
		}
		public void showAllAccount()
		{
		  for(Account acc : List)
		  {
			  System.out.println("============================================");
			  acc.showDetails();
			  
		  }
		}
		public Account searchByNumber(int number)
		{
			Account account = null;
			for(Account acc : List)
			  {
				  if(acc.getAccountNumber() == number)
				  {
					  account = acc;
					  break;
				  }
			  }
			return account;
		}
	}


